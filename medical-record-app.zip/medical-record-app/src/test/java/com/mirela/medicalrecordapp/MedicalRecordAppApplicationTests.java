package com.mirela.medicalrecordapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalRecordAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
